package main

import (
	"fmt"
	"log"

	"go.bug.st/serial"
)

// function sets up listening port
func setupPort() serial.Port {
	mode := &serial.Mode{
		Parity:   serial.NoParity,
		DataBits: 8,
		StopBits: serial.OneStopBit,
		BaudRate: 9600,
	}

	port, err := serial.Open("/dev/ttyUSB0", mode)
	if err != nil {
		log.Fatal(err)
	}
	return port
}

// function for reading sent data
func readData(port serial.Port) {
	buf := make([]byte, 128)
	for {
		n, err := port.Read(buf)
		if err != nil {
			log.Printf("Error reading data: %v\n", err)
			return
		}

		if n > 0 {
			fmt.Printf("Received: %s\n", string(buf[:n]))
		}
	}
}

func main() {
	port := setupPort()
	defer port.Close()

	readData(port)
}
