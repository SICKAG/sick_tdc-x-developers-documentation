package main

import (
	"fmt"
	"log"
	"time"

	"go.bug.st/serial"
)

// function for setting up serial port
func setupPort() serial.Port {
	mode := &serial.Mode{
		Parity:   serial.NoParity,
		DataBits: 8,
		StopBits: serial.OneStopBit,
		BaudRate: 9600,
	}

	port, err := serial.Open("/dev/ttyUSB0", mode)
	if err != nil {
		log.Fatal(err)
	}
	return port
}

// function to write data to port
func writeData(port serial.Port, message []byte) {
	for {
		_, err := port.Write(message)
		if err != nil {
			log.Printf("Error writing data: %v\n", err)
			return
		} else {
			fmt.Printf("Sent: %s\n", message)
		}
		time.Sleep(2 * time.Second)
	}
}

func main() {
	port := setupPort()
	defer port.Close()

	message := []byte("Hello world!")
	writeData(port, message)
}
