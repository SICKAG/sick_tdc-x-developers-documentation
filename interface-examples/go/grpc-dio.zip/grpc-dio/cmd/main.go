package main

import (
	"context"
	"fmt"
	"log"
	"time"

	"grpc-dio/pkg/auth"
	pb "grpc-dio/pkg/pb/protos"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/metadata"
	"google.golang.org/protobuf/types/known/emptypb"
)

// Token represents the structure of your JSON file
type Token struct {
	AccessToken  string `json:"access_token"`
	TokenType    string `json:"token_type"`
	ExpiresIn    int    `json:"expires_in"`
	RefreshToken string `json:"refresh_token"`
}

// set needed DIO device
var DIODevice = "DIO_A"

/* Lists all DIO devices */
func listAllDIOs(client pb.DigitalIOClient, ctx context.Context) {
	req := &emptypb.Empty{}
	res, err := client.ListDevices(ctx, req)
	if err != nil {
		log.Fatalf("could not write: %v", err)
	}
	fmt.Printf("Available DIO devices: %s \n", res.String())
	fmt.Printf("-------------------------\n")
}

/* Reads DIO state A */
func readDio(client pb.DigitalIOClient, ctx context.Context) string {
	req := &pb.DigitalIOReadRequest{
		Name: DIODevice,
	}

	res, err := client.Read(ctx, req)
	if err != nil {
		log.Fatalf("could not read: %v", err)
	}
	state := res.State.String()
	fmt.Printf("The state of %s is: %s\n", req.Name, state)
	return state
}

/* Changes DIO A state according to current state */
func changeDioState(client pb.DigitalIOClient, currentState string, ctx context.Context) {

	var nextState pb.IOState

	switch currentState {
	case "LOW":
		nextState = 2
	case "HIGH":
		nextState = 1
	default:
		nextState = 1
	}

	req := &pb.DigitalIOWriteRequest{
		Name:  DIODevice,
		State: nextState,
	}

	_, err := client.Write(ctx, req)
	if err != nil {
		log.Fatalf("could not write: %v", err)
	}
}

func main() {
	// Set up credentials
	creds, err := auth.NewOAuthPerRPCCredentials()
	if err != nil {
		log.Fatalf("failed to create OAuth credentials: %v", err)
	}

	address := "192.168.0.100:8081"
	conn, err := grpc.NewClient(address, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		log.Fatalf("did not connect: %v", err)
	}
	defer conn.Close()

	client := pb.NewDigitalIOClient(conn)
	md := metadata.New(map[string]string{
		"Authorization": "Bearer " + creds.Token.AccessToken,
	})
	ctx := metadata.NewOutgoingContext(context.Background(), md)

	// Prints all possible DIOs before continuously reading and setting DIO values
	listAllDIOs(client, ctx)

	for {
		state := readDio(client, ctx)
		changeDioState(client, state, ctx)
		time.Sleep(2 * time.Second)
	}
}
