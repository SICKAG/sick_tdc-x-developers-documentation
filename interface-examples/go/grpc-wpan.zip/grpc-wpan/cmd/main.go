package main

import (
	"context"
	"fmt"
	"grpc-wpan/pkg/auth"
	"grpc-wpan/pkg/pb/protos"
	"io"
	"log"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/metadata"
	"google.golang.org/protobuf/types/known/emptypb"
)

// Token represents the structure of your JSON file
type Token struct {
	AccessToken  string `json:"access_token"`
	TokenType    string `json:"token_type"`
	ExpiresIn    int    `json:"expires_in"`
	RefreshToken string `json:"refresh_token"`
}

var WPANDevice string
var client protos.WPANClient
var ctx context.Context
var minNumberOfDevices int

func derefString(ptr *string) string {
	if ptr == nil {
		return "nil"
	}
	return *ptr
}

func derefInt32(ptr *int32) string {
	if ptr == nil {
		return "nil"
	}
	return fmt.Sprintf("%d", *ptr)
}

func derefBool(ptr *bool) string {
	if ptr == nil {
		return "nil"
	}
	if *ptr {
		return "true"
	}
	return "false"
}

/* Lists all WPAN devices found during discovery */
func listWPANDevices() {
	maxRetries := 5
	retries := 0

	log.Println("Listing available devices:")

	for retries < maxRetries {
		resp, err := client.GetDevices(ctx, &emptypb.Empty{})
		if err != nil {
			log.Fatalf("could not read: %v", err)
		}

		if len(resp.Devices) > 0 {
			for _, device := range resp.Devices {
				log.Println("Device Alias:", derefString(device.Alias))
				log.Println("Device Address:", derefString(device.Address))
				log.Println("Device UUIDs:", device.Uuids)
				log.Println("Device RSSI:", derefInt32(device.Rssi))
				log.Println("Paired:", derefBool(device.Paired))
				log.Println("Bonded:", derefBool(device.Bonded))
				log.Println("Connected:", derefBool(device.Connected))
				log.Println("Trusted:", derefBool(device.Trusted))
				log.Println("Blocked:", derefBool(device.Blocked))
				log.Println("Services Resolved:", derefBool(device.ServicesResolved))
				log.Println("----")
			}
			return
		} else {
			log.Println("No devices found, retrying...")
			retries++
			if retries >= maxRetries {
				log.Println("Max retries reached, no devices found.")
				return
			}
			time.Sleep(2 * time.Second)
		}
	}
}

/* Checks the status of the device */
func checkDevice(macAddress string) bool {
	req := protos.DeviceAddress{
		Address: macAddress,
	}
	_, err := client.GetDevice(ctx, &req)
	if err != nil {
		log.Printf("MAC address %s not in available devices: %v. Stopping application...", macAddress, err)
		return false
	}
	return true
}

// uncomment to pair without connecting
/* Pairs device */
// func pairDevice(macAddress string) {
// 	req := protos.DeviceAddress{
// 		Address: macAddress,
// 	}
// 	_, err := client.Pair(ctx, &req)
// 	if err != nil {
// 		log.Fatalf("Failed to pair %s: %v", macAddress, err)
// 	}
// }

/* Connects device */
func connectDevice(macAddress string) {
	req := protos.DeviceConnection{
		Address: macAddress,
	}
	_, err := client.Connect(ctx, &req)
	if err != nil {
		log.Fatalf("Failed to connect %s: %v", macAddress, err)
	}
}

/* Attaches to HDI Input */
func attachToHDIInput(macAddress string) {
	req := protos.DeviceAddress{
		Address: macAddress,
	}
	stream, err := client.AttachToHIDInput(ctx, &req)
	if err != nil {
		log.Fatalf("Failed to pair %s: %v", macAddress, err)
	}
	for {
		inputEvent, err := stream.Recv()
		if err != nil {
			if err == io.EOF {
				log.Println("Stream closed.")
				break
			}
			log.Fatalf("Error receiving input event: %v", err)
		}
		log.Printf("Received input event: %+v\n", inputEvent)
	}
}

func main() {
	// Set up credentials
	creds, err := auth.NewOAuthPerRPCCredentials()
	if err != nil {
		log.Fatalf("failed to create OAuth credentials: %v", err)
	}

	address := "192.168.0.100:8081"

	conn, err := grpc.NewClient(address, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		log.Fatalf("did not connect: %v", err)
	}
	defer conn.Close()

	client = protos.NewWPANClient(conn)
	md := metadata.New(map[string]string{
		"Authorization": "Bearer " + creds.Token.AccessToken,
	})
	ctx = metadata.NewOutgoingContext(context.Background(), md)

	// Start device discovery via HAL service for optimal results
	listWPANDevices()

	time.Sleep(time.Second * 2)

	// set MAC address for pairing+connecting
	deviceMacAddress := "MAC_ADDR"

	if checkDevice(deviceMacAddress) {
		//pairDevice(deviceMacAddress)
		connectDevice(deviceMacAddress)
		attachToHDIInput(deviceMacAddress)
	}
}
