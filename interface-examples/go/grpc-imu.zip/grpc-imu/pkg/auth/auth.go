package auth

import (
	"context"
	_ "embed"
	"encoding/json"
	"fmt"

	"golang.org/x/oauth2"
)

type Token struct {
	AccessToken string `json:"access_token"`
	TokenType   string `json:"token_type"`
}

//go:embed token.json
var tokenJSON []byte

type OAuthPerRPCCredentials struct {
	Token *oauth2.Token
}

func (o *OAuthPerRPCCredentials) GetRequestMetadata(ctx context.Context, _ ...string) (map[string]string, error) {
	return map[string]string{
		"Authorization": fmt.Sprintf("Bearer %s", o.Token.AccessToken),
	}, nil
}

func (o *OAuthPerRPCCredentials) RequireTransportSecurity() bool {
	return true
}

func LoadTokenFromFile() (*oauth2.Token, error) {
	var token Token
	if err := json.Unmarshal(tokenJSON, &token); err != nil {
		return nil, fmt.Errorf("failed to unmarshal embedded token JSON: %w", err)
	}

	return &oauth2.Token{
		AccessToken: token.AccessToken,
		TokenType:   token.TokenType,
	}, nil
}

func NewOAuthPerRPCCredentials() (*OAuthPerRPCCredentials, error) {
	token, err := LoadTokenFromFile()
	if err != nil {
		return nil, fmt.Errorf("failed to load token: %w", err)
	}
	return &OAuthPerRPCCredentials{
		Token: token,
	}, nil
}
