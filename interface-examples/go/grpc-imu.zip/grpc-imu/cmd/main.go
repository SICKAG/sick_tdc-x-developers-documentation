package main

import (
	"context"
	"fmt"
	"log"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/metadata"
	"google.golang.org/protobuf/types/known/emptypb"

	"grpc-imu/pkg/auth"
	"grpc-imu/pkg/pb/protos"
)

/* Function for listing all available IMU sensors */
func listImuSensors(client protos.ImuClient, ctx context.Context) {
	req := &emptypb.Empty{}
	res, err := client.ListDevices(ctx, req)
	if err != nil {
		log.Fatalf("could not list devices: %v", err)
	}
	fmt.Printf("Available IMU sensors: %s\n", res.String())
	fmt.Printf("-------------------------\n")
}

/* Function for readign single raw sample */
func readFromOneSensor(client protos.ImuClient, ctx context.Context) {
	/* Change request if needed */
	req := &protos.ChooseDeviceRequest{
		DeviceName: "accelerometer",
	}

	res, err := client.ReadSampleRaw(ctx, req)
	if err != nil {
		log.Fatalf("could not read sample: %v", err)
	}

	fmt.Printf("Raw sample: %s\n", res.String())
	fmt.Printf("-------------------------\n")
}

/* Function for setting sampling frequency */
func setSamplingFrequency(client protos.ImuClient, ctx context.Context) {
	/* Change request if needed */
	req := &protos.SetSamplingFrequencyRequest{
		DeviceName: "accelerometer",
		Frequency:  100,
	}
	_, err := client.SetSamplingFrequency(ctx, req)
	if err != nil {
		log.Fatalf("could not set sampling frequency: %v", err)
	}

	fmt.Printf("Sampling frequency set to: 100 Hz\n")
	fmt.Printf("-------------------------\n")
}

/* Function for reading buffered data stream */
func readBufferedDataStream(client protos.ImuClient, ctx context.Context) {
	/* Change request if needed */
	req := &protos.ReadBufferedDataStreamRequest{
		DeviceName:   "accelerometer",
		FilterLength: 10,
	}

	stream, err := client.ReadBufferedDataStream(ctx, req)
	if err != nil {
		log.Fatalf("failed to call ReadBufferedDataStream: %v", err)
	}

	fmt.Println("Starting to receive data from the buffered stream...")
	for {
		res, err := stream.Recv()
		if err != nil {
			if err.Error() == "EOF" {
				fmt.Println("Stream ended.")
				break
			}
			log.Fatalf("error receiving data from stream: %v", err)
		}
		fmt.Printf("Received data: %v\n", res)
	}
}

func main() {
	creds, err := auth.NewOAuthPerRPCCredentials()
	if err != nil {
		log.Fatalf("failed to create OAuth credentials: %v", err)
	}

	conn, err := grpc.NewClient("192.168.0.100:8081", grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		log.Fatalf("failed to connect: %v", err)
	}
	defer conn.Close()

	client := protos.NewImuClient(conn)

	md := metadata.New(map[string]string{
		"Authorization": "Bearer " + creds.Token.AccessToken,
	})
	ctx := metadata.NewOutgoingContext(context.Background(), md)

	// List all IMU sensors
	listImuSensors(client, ctx)
	time.Sleep(time.Second)

	// Read single sample
	readFromOneSensor(client, ctx)
	time.Sleep(time.Second)

	// Set sampling frequency
	setSamplingFrequency(client, ctx)
	time.Sleep(time.Second)

	// Read stream
	readBufferedDataStream(client, ctx)
}
