package main

import (
	canSetup "can/pkg"
	"flag"
	"fmt"
	"log"
	"sync"
	"time"

	"github.com/go-daq/canbus"
)

func main() {

	setup := flag.Bool("setup", false, "Set up the CAN interface (default is false)")
	flag.Parse()

	if *setup {
		err := canSetup.SetUpCan()
		if err != nil {
			log.Fatalf("Failed to set up CAN interface: %v", err)
		}
	}

	// Initialize CAN bus connection
	can, err := canbus.New()
	if err != nil {
		log.Fatalf("Failed to open CAN socket: %v", err)
	}
	defer can.Close()

	err = can.Bind("can0")
	if err != nil {
		log.Fatalf("Cannot bind to can socket: %s", err)
	}

	// Start sender and receiver goroutines
	var wg sync.WaitGroup
	wg.Add(2)

	// Sender goroutine
	go sendData(can, &wg)

	// Receiver goroutine
	go receiveData(can, &wg)

	// Wait for all goroutines to finish (though they'll run forever)
	wg.Wait()
}

func sendData(can *canbus.Socket, wg *sync.WaitGroup) {
	defer wg.Done()

	// Prepare data to send
	data := []byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08}
	frame := canbus.Frame{
		ID:   0x123,
		Data: data,
	}

	// Send frame and handle errors
	for {
		if _, err := can.Send(frame); err != nil {
			log.Printf("Failed to send CAN frame: %v", err)
		} else {
			fmt.Println("Sent CAN frame:", frame)
		}

		// Sleep for 1 second before sending again
		time.Sleep(1 * time.Second)
	}
}

func receiveData(can *canbus.Socket, wg *sync.WaitGroup) {
	defer wg.Done()

	// Infinite loop to receive frames
	for {
		frame, err := can.Recv()
		if err != nil {
			log.Printf("Failed to receive CAN frame: %v", err)
		} else {
			log.Println("Received CAN frame:", frame)
		}
	}
}
