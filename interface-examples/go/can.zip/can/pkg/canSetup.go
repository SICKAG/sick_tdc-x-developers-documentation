package canSetup

import (
	"fmt"
	"log"
	"os/exec"
)

func SetUpCan() error {
	cmd := exec.Command("ip", "link", "set", "can0", "type", "can", "bitrate", "1000000")
	err := cmd.Run()
	if err != nil {
		return fmt.Errorf("failed to set CAN interface bitrate: %w", err)
	}

	cmd = exec.Command("ip", "link", "set", "can0", "up")
	err = cmd.Run()
	if err != nil {
		return fmt.Errorf("failed to bring CAN interface up: %w", err)
	}

	log.Println("CAN interface set up successfully.")
	return nil
}
