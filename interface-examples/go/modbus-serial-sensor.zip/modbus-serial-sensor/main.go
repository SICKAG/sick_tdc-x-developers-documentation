package main

import (
	"fmt"
	"log"
	"time"

	"go.bug.st/serial"
)

/* function sets up serial port for reading and writing */
func setupPort() serial.Port {
	mode := &serial.Mode{
		BaudRate: 9600,
		Parity:   serial.NoParity,
		DataBits: 8,
	}
	port, err := serial.Open("/dev/ttyUSB0", mode)
	if err != nil {
		log.Fatal(err)
	}
	return port
}

/* function for parsing temperature and humidity */
func parseValues(rawData []byte) {
	tempHigh := rawData[3]
	tempLow := rawData[4]
	temperatureRaw := (uint16(tempHigh) << 8) | uint16(tempLow)
	realTemperature := float64(temperatureRaw) / 10.0

	humidityHigh := rawData[5]
	humidityLow := rawData[6]
	humidityRaw := (uint16(humidityHigh) << 8) | uint16(humidityLow)
	realHumidity := float64(humidityRaw) / 10.0

	fmt.Printf("Temperature: %.2f °C\n", realTemperature)
	fmt.Printf("Humidity: %.2f %%\n", realHumidity)
}

/* sends message to sensor and awaits response */
func getTemperatureHumidity(message []byte, port serial.Port) {
	// send message to port
	_, err := port.Write(message)
	if err != nil {
		log.Fatalf("Error writing to serial port: %v", err)
	}

	// give sensor time to parse message
	time.Sleep(1 * time.Second)

	// get response
	response := make([]byte, 256)
	n, err := port.Read(response)
	if err != nil {
		log.Fatalf("Error reading from serial port: %v", err)
	}
	fmt.Printf("Received response: %X\n", response[:n])

	// parse values for readable data
	parseValues(response)
}

func main() {

	port := setupPort()
	defer port.Close()

	// to fetch temeprature and humidity, send a message byte
	message := []byte{0x01, 0x03, 0x00, 0x00, 0x00, 0x02, 0xC4, 0x0B}
	getTemperatureHumidity(message, port)

}
