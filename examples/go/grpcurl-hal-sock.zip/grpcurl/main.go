package main

import (
	"fmt"
	"log"
	"os"
	"os/exec"
)

func main() {
	cmd := exec.Command("grpcurl", "-emit-defaults", "-plaintext", "-unix=true", "/run/hal/hal.sock", "list")

	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr

	fmt.Println("Running grpcurl command...")
	if err := cmd.Run(); err != nil {
		log.Fatalf("Error running grpcurl command: %v\n", err)
	}
}
