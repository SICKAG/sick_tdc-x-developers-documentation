package main

import (
	"context"
	"fmt"
	"log"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/metadata"
	"google.golang.org/protobuf/types/known/emptypb"

	"grpc-ain/pkg/auth"
	"grpc-ain/pkg/pb/protos"
)

var AINDevice = "AI_A"

/* Function for listing all available AIN devices */
func listAINDevices(client protos.AnalogINClient, ctx context.Context) {
	req := &emptypb.Empty{}
	res, err := client.ListDevices(ctx, req)
	if err != nil {
		log.Fatalf("could not write: %v", err)
	}
	fmt.Printf("Available AIN devices: %s \n", res.String())
	fmt.Printf("-------------------------\n")
}

/* Function for reading AIN values */
func readAINVal(client protos.AnalogINClient, ctx context.Context) {
	req := &protos.AnalogInReadRequest{
		Name: AINDevice,
	}

	res, err := client.Read(ctx, req)
	if err != nil {
		log.Fatalf("could not read: %v", err)
	}

	fmt.Printf("%s Values: \n adcRaw: %d \n converted: %f \n unit: %s \n", AINDevice, res.AdcRaw, res.Converted, res.Unit)
}

/* Function for changing the AIN mode - [VOLTAGE|CURRENT] */
/* Uncomment here if using mode change */

/*
func changeAINMode(client protos.AnalogINClient) {
	// mode set to Current
	req := &protos.AnalogInSetMeasureModeRequest{
		Name: AINDevice,
		Mode: protos.AnalogInMode_Current,
	}
	_, err := client.SetMeasureMode(context.Background(), req)
	if err != nil {
		log.Fatalf("could not write: %v", err)
	} else {
		fmt.Printf("Measure mode set to mode: %d", req.Mode)
	}
}
*/

func main() {
	// Set up credentials
	creds, err := auth.NewOAuthPerRPCCredentials()
	if err != nil {
		log.Fatalf("failed to create OAuth credentials: %v", err)
	}

	address := "192.168.0.100:8081"
	conn, err := grpc.NewClient(address, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		log.Fatalf("did not connect: %v", err)
	}
	defer conn.Close()

	client := protos.NewAnalogINClient(conn)
	md := metadata.New(map[string]string{
		"Authorization": "Bearer " + creds.Token.AccessToken,
	})
	ctx := metadata.NewOutgoingContext(context.Background(), md)

	// list all AIN devices
	listAINDevices(client, ctx)

	/* Uncomment here if using mode change */
	//changeAINMode(client)

	// continuously read AIN values
	for {
		readAINVal(client, ctx)
		time.Sleep(time.Second)
	}
}
