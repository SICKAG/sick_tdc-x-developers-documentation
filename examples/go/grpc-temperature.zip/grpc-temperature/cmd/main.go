package main

import (
	"context"
	"fmt"
	"log"

	"grpc-temp-sensor/pkg/auth"
	protos "grpc-temp-sensor/pkg/pb"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/metadata"
	"google.golang.org/protobuf/types/known/emptypb"
)

// Lists all temperature sensors on device
func listTemperatureSensors(ctx context.Context, client protos.TemperatureSensorClient) *protos.TemperatureSensorListDeviceResponse {
	req := &emptypb.Empty{}
	res, err := client.ListDevices(ctx, req)
	if err != nil {
		log.Fatalf("could not read: %v", err)
	}
	fmt.Printf("Available Temperature Sensors: %s \n", res.String())
	fmt.Printf("-----------------------------\n")

	return res
}

// reads temperature from given sensor
func readTemperature(ctx context.Context, client protos.TemperatureSensorClient, device string) {
	req := protos.TemperatureSensorReadRequest{
		Name: device,
	}
	res, err := client.Read(ctx, &req)
	if err != nil {
		log.Fatalf("couldn't read from temperature sensor: %v", err)
	}
	fmt.Printf("%s temperature: %.2f %s\n", device, res.Value, res.Unit)
}

func main() {

	creds, err := auth.NewOAuthPerRPCCredentials()
	if err != nil {
		log.Fatalf("failed to create OAuth credentials: %v", err)
	}

	address := "192.168.0.100:8081"
	conn, err := grpc.NewClient(address, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		log.Fatalf("did not connect: %v", err)
	}
	defer conn.Close()

	client := protos.NewTemperatureSensorClient(conn)

	md := metadata.New(map[string]string{
		"Authorization": "Bearer " + creds.Token.AccessToken,
	})
	ctx := metadata.NewOutgoingContext(context.Background(), md)

	sensorList := listTemperatureSensors(ctx, client)

	// Reads temperature from all sensors
	for _, dev := range sensorList.Devices {
		readTemperature(ctx, client, dev.Name)
	}
}
